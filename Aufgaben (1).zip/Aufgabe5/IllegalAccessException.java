/**
 * 
 */
package Aufgabe5;

/**
 * @author Justus Boos 2388000
 *
 */
public class IllegalAccessException extends Exception{
	
		
		public IllegalAccessException(String message) {
			super (message);
		}

}

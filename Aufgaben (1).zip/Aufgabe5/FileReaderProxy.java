/**
 * 
 */
package Aufgabe5;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Collection;

/**
 * @author Justus Boos 2388000
 *
 */
public class FileReaderProxy {
	
	FileReader fr;
	Collection<String> col;
	

	
	public FileReaderProxy(FileReader fr) {
		super();
		this.fr = fr;
	}


	public FileReaderProxy(FileReader fr, Collection<String> col) {
		super();
		this.fr = fr;
		this.col = col;
	}
	
	
	
	public void addForbiden(String forbiden) {
		col.add(forbiden);	
	}

	public void deleteForbidden(String forbiden) {
		col.remove(forbiden);
	}
	
	public void readFile(String forbiden) throws IllegalAccessException {
		try {
			fr = new FileReader(forbiden);
			
		} catch (FileNotFoundException e) {			
		
			throw new IllegalAccessException("Verbotener Zugriff");
		}
	}
	
	
}

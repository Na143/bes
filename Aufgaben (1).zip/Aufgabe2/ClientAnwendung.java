/**
 * 
 */
package Aufgabe2;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;


/**
 * @author Justus Boos 2388000
 *
 */
public class ClientAnwendung {
	
	static boolean isRunning = true;
	
public static void main(String[] args) {
		
		ClientAnwendung client = new ClientAnwendung();
		client.createClient();
		
	}

	public void createClient() {
		
		try {
			//Network Connection
			Socket socket = new Socket("127.0.0.1",3445);
			//write from Network
			PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
			//read from Network
			Scanner scanner = new Scanner(socket.getInputStream());
			//Message
			System.out.println("Message:");
			//read from keyboard
			Scanner keyboard = new Scanner(System.in);
			
			while(isRunning) {
			//Message from Keyboard written over Network
			String message = keyboard.nextLine();
			if(message.equals("exit")) {
				isRunning = false;
			}
			
			printWriter.println(message);
			printWriter.flush();
			//print to Console from Network
			System.out.println(scanner.nextLine());
			}
			
			//Closing Block
			keyboard.close();
			scanner.close();
			printWriter.close();
			socket.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}

}

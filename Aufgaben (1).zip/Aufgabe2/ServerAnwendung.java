/**
 * 
 */
package Aufgabe2;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;



/**
 * @author Justus Boos 2388000
 *
 */
public class ServerAnwendung implements Runnable {
	
	static boolean isRunning = true;
	
	public static void main(String[] args) {
		
		ServerAnwendung server;
		try {
			
			Scanner scanner = new Scanner(System.in);
			server = new ServerAnwendung(new ServerSocket(3445));
			
			Thread runnable = new Thread(server);
			runnable.start();
		
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	
	ServerSocket serverSocket;
	
	public ServerAnwendung(ServerSocket serverSocket) {
		super();
		this.serverSocket = serverSocket;
	}

	
	public static void stopTheThread() {
		
			isRunning = false;
	
	}
	

	@Override
	public void run() {
		
		try {
			//Network Connection
			Socket socket = serverSocket.accept();
			//write from Network
			PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
			//read from Network
			Scanner scanner = new Scanner(socket.getInputStream());
			
			
			while(isRunning) {
		    //print to Console from Network	
			String input = scanner.nextLine();	
			if (input.equals("exit")) {
				ServerAnwendung.stopTheThread();
			}
			System.out.println(input);
			//Message from Server
			printWriter.println("Die Nachricht wurde empfangen und gespeichert");
			printWriter.flush();
			
			}
			
			
			//Closing Block
			printWriter.close();
			scanner.close();
			socket.close();
			serverSocket.close();
			
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

	

}

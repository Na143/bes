/**
 * 
 */
package Aufgabe4;

import java.util.Arrays;
import java.util.List;

/**
 * @author Justus Boos 2388000
 *
 */
public class TemperaturAnalyseMain {
	
	public static  List<Integer> temps = Arrays.asList(8,5,17,20,-1);
	
	
	public static void main(String[] args) {
			
		
		try {
			
			if(!temps.isEmpty()) {
			TemperaturAnalyse.getDurchschnittstemperatur(temps);
			TemperaturAnalyse.getGroessterWechsel(temps);
			TemperaturAnalyse.getKaeltesterTag(temps);
			
			}
		} catch (IllegalArgumentException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(TemperaturAnalyse.getKaeltesterTag(temps));
		System.out.println(TemperaturAnalyse.getGroessterWechsel(temps));
		System.out.println(TemperaturAnalyse.getDurchschnittstemperatur(temps));
		
		
		
	}

}

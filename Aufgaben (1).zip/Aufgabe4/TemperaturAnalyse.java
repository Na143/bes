/**
 * 
 */
package Aufgabe4;

import java.util.List;

/**
 * @author Justus Boos 2388000
 *
 */
public class TemperaturAnalyse {
	
	public static int getKaeltesterTag(List<Integer> temperaturen) {
		
		int lowTemp = temperaturen.get(0);
		int index = 0;
		
		for(int i = 0; i< temperaturen.size(); i++) {
			if(lowTemp >= temperaturen.get(i)) {
				lowTemp = temperaturen.get(i);  
				index = i;
			}
			
		}
		return index;
		
	}
	
	
	public static double getDurchschnittstemperatur(List<Integer> temperaturen) {
		
		int avgTemp = temperaturen.get(0);
		double result = 0.0;
		
		for(int i = 0; i< temperaturen.size(); i++) {
			avgTemp += temperaturen.get(i);
			result = avgTemp/temperaturen.size();
		}
		 
		return result;
	}

	
	public static double getGroessterWechsel(List<Integer> temperaturen) {
		
		double bigChaTemp = Math.abs(temperaturen.get(0)-temperaturen.get(1)); 
		
		for(int i = 0; i < temperaturen.size()-1; i++) {
			if(bigChaTemp < Math.abs(temperaturen.get(i)-temperaturen.get(i+1))) {
				bigChaTemp = Math.abs(temperaturen.get(i)-temperaturen.get(i+1));
			}
			
		}
		
		
		return bigChaTemp;
	}
	
}

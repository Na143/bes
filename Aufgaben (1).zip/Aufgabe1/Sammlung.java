/**
 * 
 */
package Aufgabe1;

/**
 * @author Justus Boos 2388000
 *
 */
public class Sammlung {
	
	private java.util.List<Object> xElemente;
	
	public Object getFuenftes() {
		
		Object f�nftesElement = xElemente.get(4);
		
		return f�nftesElement;
	}

}

/**
 * 
 */
package Aufgabe3;

/**
 * @author Justus Boos 2388000
 *
 */
public class Buch implements Comparable<Buch> {

	private String titel;
	private String isbn;
	private String author;

	public Buch(String titel, String isbn, String author) {
		super();
		this.titel = titel;
		this.isbn = isbn;
		this.author = author;
	}

	public String getTitel() {
		return titel;
	}

	public void setTitel(String titel) {
		this.titel = titel;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	@Override
	public int compareTo(Buch o) {
		int val = titel.compareTo(o.titel); // name mit name vergleichen
		if (val == 0) {
			val = author.compareTo(o.getAuthor());
		}
		return val;
	}

	@Override
	public String toString() {
		return "Buch [titel=" + titel + ", isbn=" + isbn + ", author=" + author + "]";
	}

}

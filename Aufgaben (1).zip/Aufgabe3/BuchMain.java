/**
 * 
 */
package Aufgabe3;

import java.util.ArrayList;
import java.util.Collections;

/**
 * @author Justus Boos 2388000
 *
 */
public class BuchMain {
	
	public static void main(String[] args) {
		
		ArrayList<Buch> buecher = new ArrayList();
		buecher.add(new Buch("Haus","123","Justus"));
		buecher.add(new Buch("Mond","113","Nikolaus"));
		buecher.add(new Buch("Sonne","154","Nikolaus"));
		buecher.add(new Buch("Sonne","143", "Benjamin"));
		
		
		Collections.sort(buecher);
		
		for(Buch buch : buecher) {
			System.out.println(buch.toString());
		}
		
		
	}

}

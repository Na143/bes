/**
 * 
 */
package Aufgabe6;

/**
 * @author Justus Boos 2388000
 *
 */
public class Auto {
	
	String typ;
	String farbe;
	int herstellerNr;
	
	public Auto(String typ, String farbe, int herstellerNr) {
		super();
		this.typ = typ;
		this.farbe = farbe;
		this.herstellerNr = herstellerNr;
	}

	public String getTyp() {
		return typ;
	}

	public void setTyp(String typ) {
		this.typ = typ;
	}

	public String getFarbe() {
		return farbe;
	}

	public void setFarbe(String farbe) {
		this.farbe = farbe;
	}

	public int getHerstellerNr() {
		return herstellerNr;
	}

	public void setHerstellerNr(int herstellerNr) {
		this.herstellerNr = herstellerNr;
	}
	


}

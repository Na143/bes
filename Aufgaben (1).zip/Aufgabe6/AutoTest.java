/**
 * 
 */
package Aufgabe6;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 * @author Justus Boos 2388000
 *
 */
class AutoTest {

	@Test
	void test() {
		fail("Not yet implemented");
		
	}

	//BeforeAll muss static
@BeforeAll											//Datenbank Zugriff einmal �berpr�fen oder ServerConnection (Accept)
static void begin() {
System.out.println("Vor allem");
}


@BeforeEach											//Bevor jeder Testmethode 
void init() {
Auto auto = new Auto("Sportwagen","Gelb",12312);
}

@Test
void test1() {
System.out.println("Test");
Auto auto = new Auto("Sportwagen","Gelb",12312);

String typ = "Porsche";

auto.setTyp(typ);

assertEquals(typ, auto.getTyp()); //typ exspected, auto.getTyp actual

}

@Test
void test2() {
System.out.println("Test2");
Auto auto2 = new Auto("Sportwagen","Gelb",12312);
String farbe = "Gelb";
auto2.setFarbe(farbe);

assertEquals(farbe, auto2.getFarbe()); //color exspected, auto2.getFarbe actual

}

@Test
void test3() {
System.out.println("Test3");
Auto auto3 = new Auto("Sportwagen","Gelb",12312);
int herstellernummer = 1245;

auto3.setHerstellerNr(herstellernummer);

assertNotEquals("Harry", auto3.getHerstellerNr()); //herstellerNr. exspected, auto3.getHersteller actual

}


@AfterEach
void afterMethods() {
System.out.println("After Each Method");

}


@AfterAll											//AfterAll muss static
static void end() {
System.out.println("Nach allem");

}
}
	
	


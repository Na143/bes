package junit;

import java.util.Scanner;

public class TicTacToeMain {

	public static void main(String[] args) {

		TicTacToe game1 = new TicTacToe(1);
		Scanner scanner = new Scanner(System.in);

		while (game1.isGameOver() == false) {
			game1.printGame();
			System.out.println("Player " + game1.getPlayer() + ", choose a field from 1-9: ");
			while (game1.setSymbol(game1.getPlayer(), scanner.nextInt() - 1) == false) { // if unable to set symbol
				game1.printGame();
				System.out.println("Field already taken, pick another.");
			}

			if (game1.hasWon(game1.getPlayer())) { // if current player has won
				game1.printGame();
				System.out.println("Player " + game1.getPlayer() + " has won the game!");
				break;
			}

			if (game1.isDraw()) {
				game1.printGame();
				System.out.println("Draw!");
				break;
			}

			game1.changePlayer();
		}

		scanner.close();
	}

}

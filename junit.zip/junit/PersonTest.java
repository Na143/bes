package junit;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PersonTest {
	
	Person person;
	
	@BeforeEach
	void init() {
		person = new Person("Tom", "Kalberg");
	}

	@Test
	void testFirstName() {
		
		String newFirstName = "Tobias";
		
		person.setFirstName(newFirstName);
		
		assertEquals(newFirstName, person.getFirstName());
		
	}
	
	@Test
	void testLastName() {
		
		String newLastName = "Bremer";
		
		person.setLastName(newLastName);
		
		assertEquals(newLastName, person.getLastName());
		
	}
	
}

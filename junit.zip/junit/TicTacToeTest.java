package junit;

import static org.junit.jupiter.api.Assertions.*;

import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class TicTacToeTest {

	TicTacToe game;

	@BeforeEach
	void init() {
		game = new TicTacToe(1);
	}

	@ParameterizedTest
	@MethodSource
	void testSetPlayer(int number) {

		int newPlayer = number;
		game.setPlayer(newPlayer);
		assertEquals(newPlayer, game.getPlayer());

	}

	static IntStream testSetPlayer() {
		return IntStream.range(0, 5);

	}

	@ParameterizedTest
	@MethodSource
	void testIsGameOver(int symbol, int[] indices) {
		for (int i : indices) {
			game.setSymbol(symbol, i);
		}
		assertTrue(game.isGameOver());

	}

	static Stream<Arguments> testIsGameOver() {
		return Stream.of(
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 2 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 2, 3, 4, 5 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8 }));
	}

	@ParameterizedTest
	@MethodSource
	void testSetSymbol(int symbol, int[] indices) {
		for (int i : indices) {
			assertTrue(game.setSymbol(symbol, i));
		}
	}

	static Stream<Arguments> testSetSymbol() {
		return Stream.of(
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 2 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 1, 2, 3 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 1 }));
	}

	@ParameterizedTest
	@MethodSource
	void testHasWon(int symbol, int[] indices) {
		for (int i : indices) {
			game.setSymbol(symbol, i);
		}
		assertTrue(game.hasWon(symbol));

	}

	static Stream<Arguments> testHasWon() {
		return Stream.of(
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 3 }), // gewinnt nicht
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 1, 2 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 3, 4, 5 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 6, 7, 8 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 3, 6 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 1, 4, 7 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 2, 5, 8 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 4, 8 }),
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 2, 4, 6 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 0, 1, 3 }), // gewinnt nicht
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 0, 1, 2 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 3, 4, 5 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 6, 7, 8 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 0, 3, 6 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 1, 4, 7 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 2, 5, 8 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 0, 4, 8 }),
				Arguments.of(TicTacToe.SYMBOL_X, new int[] { 2, 4, 6 }));

	}

	@ParameterizedTest
	@MethodSource
	void testIsDraw(int player1, int[] indices1, int player2, int[] indices2) {
		for (int i : indices1) {
			game.setSymbol(player1, i);
		}
		for (int j : indices2) {
			game.setSymbol(player2, j);
		}

		assertTrue(game.isDraw());

	}

	static Stream<Arguments> testIsDraw() {
		return Stream.of(
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 0, 2, 4, 6, 7 }, TicTacToe.SYMBOL_X,
						new int[] { 1, 3, 5, 8 }), // Player 1 wins
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 1, 2, 4, 5 }, TicTacToe.SYMBOL_X,
						new int[] { 0, 3, 6, 7 }), // Player 2 wins
				Arguments.of(TicTacToe.SYMBOL_O, new int[] { 1, 3, 4, 6, 8 }, TicTacToe.SYMBOL_X,
						new int[] { 0, 2, 5, 7 })); // Draw
	}

}

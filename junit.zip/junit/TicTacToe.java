package junit;

public class TicTacToe {

	private int player;

	final static int NOT_SET = 0;
	final static int SYMBOL_O = 1;
	final static int SYMBOL_X = 2;

	int[] field = { NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET };

	public TicTacToe(int player) {
		super();
		this.player = player;
	}

	public int getPlayer() {
		return player;
	}

	public void setPlayer(int player) {
		if (player < 1 || player > 2) { // if player number is not 1 or 2
			throw new IllegalArgumentException("Player must be 1 or 2");
		}
		this.player = player;
	}

	public boolean isGameOver() {
		for (int i = 0; i < field.length; i++) {
			if (field[i] == NOT_SET) { // if any field is still empty (NOT_SET)
				return false;
			}
		}
		return true;
	}

	public int[] getField() {
		return field;
	}

	public void changePlayer() { // switches between player 1 and 2
		if (player == 1) {
			setPlayer(2);
		} else {
			setPlayer(1);
		}
	}

	public boolean setSymbol(int symbol, int index) {

		if (index >= 0 || index <= 8) { // index must be between 0 and 8
			if (symbol == SYMBOL_O || symbol == SYMBOL_X) { // symbol must be either 1 or 2
				if (field[index] == NOT_SET) { // field must be empty (NOT_SET)
					field[index] = symbol; // sets the desired field
					return true;
				}
			}
		}
		return false;
	}

	public boolean hasWon(int player) {

		for (int i = 0; i < 3; i++) { // Spalten
			if (field[i] == field[i + 3] && field[i + 3] == field[i + 6] && field[i] == player) {
				return true;
			}
		}

		for (int i = 0; i < 9; i += 3) { // Zeilen
			if (field[i] == field[i + 1] && field[i + 1] == field[i + 2] && field[i] == player) {
				return true;
			}
		}

		if (field[0] == player && field[4] == player && field[8] == player) { // 1. Diagonale
			return true;
		}

		if (field[2] == player && field[4] == player && field[6] == player) { // 2. Diagonale
			return true;
		}
		return false;
	}

	public boolean isDraw() {
		if (isGameOver() == false || hasWon(1) == true || hasWon(2) == true) { //game is not a draw when isGameOver=false or a player has won
			return false;
		} else {
			return true;
		}
	}
	
	public void printGame() {
		for (int i = 0; i < 3; i++) {
			System.out.println(" " + getField()[0 + i * 3] + " " + getField()[1 + i * 3] + " "
					+ getField()[2 + i * 3]);
		}
	}

}
